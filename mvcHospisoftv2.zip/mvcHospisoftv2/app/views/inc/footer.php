
  <footer class="pt-5 my-5 text-muted border-top">
    Created by the Bootstrap team &middot; &copy; 2021
  </footer>
</div>


    <script src="<?php echo URLROOT; ?>js/bootstrap.bundle.min.js"></script>

      
  </body>
</html>