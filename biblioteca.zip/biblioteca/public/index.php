<?php

//echo " esta es la vista de inicio";
require_once '../app/Booteo.php'; //cargamos las librerias bases del framework
$Core= new Core();