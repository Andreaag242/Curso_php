## modelo vista controlador con php puro

la carpeta app contiene la logica del mvc
en el subdirectori libs tendremos las clase base del sistema

la carpeta public el material que se puede acceder publicamente


ojo: este Mvc es basado en Brad traversy, libro pendiente
